import streamlit as st
import pandas as pd
import plotly.express as px
import os
import warnings

# Suppress warnings
warnings.filterwarnings('ignore')

# Set up the Streamlit page configuration
st.set_page_config(page_title="BikeGear", page_icon=":mag:", layout="wide")

# Title of the application
st.title(":bar_chart: Almacen de Ventas 'BikeGear'")
st.markdown('<style>div.block-container{padding-top:3rem;}</style>', unsafe_allow_html=True)

df = pd.read_excel("DatosBikeGear.xlsx", header=0)

col1, col2 = st.columns((2))
print(df.columns)

with col1:
    year = st.selectbox("Seleccione Año", df["Año"].unique())
    
with col2:
    month = st.selectbox("Seleccione Mes", df["Mes"].unique())

# Filter the DataFrame based on the selected year and month
filtered_df = df[(df["Año"] == year) & (df["Mes"] == month)].copy()
filtered_df_year = df[(df["Año"] == year)].copy()
    
    # Sidebar for filtering options
st.sidebar.header("Choose your filter: ")

    # Multiselect for Sucursal filtering
ciudad = st.sidebar.multiselect("Seleccione la ciudad", filtered_df["Ciudad"].unique())
filtered_df = filtered_df[filtered_df["Ciudad"].isin(ciudad)] if ciudad else filtered_df

    # Multiselect for Sucursal filtering
sucursal = st.sidebar.multiselect("Pick your Sucursal", filtered_df["Sucursal"].unique())
filtered_df = filtered_df[filtered_df["Sucursal"].isin(sucursal)] if sucursal else filtered_df
    
    # Multiselect for Categoria filtering
categoria = st.sidebar.multiselect("Pick the Categoria", filtered_df["Categoria del Producto"].unique())
filtered_df = filtered_df[filtered_df["Categoria del Producto"].isin(categoria)] if categoria else filtered_df
    
    # Group the filtered data by Categoria and sum Ingresos
categoria_df = filtered_df.groupby(by=["Categoria del Producto"], as_index=False)["Ingresos"].sum()
    
    # Bar chart for Category-wise Ingresos



   # Bar chart for Category-wise Ingresos
with col1:
    st.subheader("Categoria wise Ingresos")
    fig = px.bar(categoria_df, x="Categoria del Producto", y="Ingresos", 
                      text=['${:,.2f}'.format(x) for x in categoria_df["Ingresos"]],
                      template="seaborn")
    st.plotly_chart(fig, use_container_width=True, height=200)
    
    # Pie chart for Ciudad-wise Ingresos
with col2:
    st.subheader("Ciudad wise Ingresos")
    ciudad_df = filtered_df.groupby(by=["Ciudad"], as_index=False)["Ingresos"].sum()
    fig = px.pie(ciudad_df, values="Ingresos", names="Ciudad", hole=0.5)
    fig.update_traces(text=ciudad_df["Ciudad"], textposition="outside")
    st.plotly_chart(fig, use_container_width=True)


cl1, cl2 = st.columns((2))
    
    # Expandable section for Categoria View Data
with cl1:
    with st.expander("Categoria_ViewData"):
        st.write(categoria_df.style.background_gradient(cmap="Blues"))
        csv = categoria_df.to_csv(index=False).encode('utf-8')
        st.download_button("Download Data", data=csv, file_name="Categoria.csv", mime="text/csv",
                                help='Click here to download the data as a CSV file')
    
    # Expandable section for Ciudad View Data
with cl2:
    with st.expander("Ciudad_ViewData"):
        ciudad_df = filtered_df.groupby(by="Ciudad", as_index=False)["Ingresos"].sum()
        st.write(ciudad_df.style.background_gradient(cmap="Oranges"))
        csv = ciudad_df.to_csv(index=False).encode('utf-8')
        st.download_button("Download Data", data=csv, file_name="Ciudad.csv", mime="text/csv", help='Click here to download the data as a CSV file')


    # Create a 'month_year' column for time series analysis
filtered_df_year["month_year"] = filtered_df_year["Año"].astype(str) + " " + filtered_df_year["Mes"]

filtered_df_year = filtered_df_year[filtered_df_year['Año'] == year]

st.subheader('Time Series Analysis')
    
    # Create a DataFrame for monthly ingresos
linechart = pd.DataFrame(filtered_df_year.groupby("month_year")["Ingresos"].sum()).reset_index()
print(linechart)
    # Line chart for monthly ingresos
fig2 = px.line(linechart, x="month_year", y="Ingresos", labels={"Ingresos": "Amount"}, height=500, width=1000, template="gridon")
st.plotly_chart(fig2, use_container_width=True)



 # Expandable section to view time series data
with st.expander("View Data of TimeSeries:"):
    st.write(linechart.T.style.background_gradient(cmap="Blues"))
    csv = linechart.to_csv(index=False).encode("utf-8")
    st.download_button('Download Data', data=csv, file_name="TimeSeries.csv", mime='text/csv')
    
    # Create two columns for segment and category pie charts
chart1, chart2 = st.columns((2))

    # Pie chart for Genero-wise Ingresos
with chart1:
    st.subheader('Genero wise Ingresos')
    genero_df = filtered_df.groupby(by=["Genero del Cliente"], as_index=False)["Ingresos"].sum()
    fig = px.pie(genero_df, values="Ingresos", names="Genero del Cliente", template="plotly_dark")
    fig.update_traces(text=genero_df["Genero del Cliente"], textposition="inside")
    st.plotly_chart(fig, use_container_width=True)
    
    # Pie chart for Categoria-wise Ingresos
with chart2:
    st.subheader('Categoria wise Ingresos')
    fig = px.pie(categoria_df, values="Ingresos", names="Categoria del Producto", template="gridon")
    fig.update_traces(text=categoria_df["Categoria del Producto"], textposition="inside")
    st.plotly_chart(fig, use_container_width=True)



    
# Display a sample summary table for filtered data
st.subheader(":point_right: Sample Data Summary")
with st.expander("Summary_Table"):
    df_sample = filtered_df[0:5][["Sucursal", "Ciudad", "Categoria del Producto", "Ingresos", "Cantidad"]]
    st.write(filtered_df.style.background_gradient(cmap="cividis"))  # Asegúrate de usar 'cividis' en minúsculas

    


    # Create a scatter plot for Ingresos vs. Costo
data1 = px.scatter(filtered_df, x="Ingresos", y="Costo", size="Cantidad", 
                        hover_name="Subcategoria", color="Categoria del Producto")
data1['layout'].update(title="Relationship between Ingresos and Costo using Scatter Plot.",
                           titlefont=dict(size=20), xaxis=dict(title="Ingresos", titlefont=dict(size=19)),
                           yaxis=dict(title="Costo", titlefont=dict(size=19)))
st.plotly_chart(data1, use_container_width=True)
    
    # Expandable section to view detailed filtered data
with st.expander("View Data"):
    st.write(filtered_df.iloc[:500, :].style.background_gradient(cmap="Oranges"))
    
    
# Treemap for hierarchical sales view
st.subheader("Hierarchical view of Sales using TreeMap")
fig3 = px.treemap(filtered_df, path=["Ciudad", "Sucursal", "Categoria del Producto"], values="Ingresos", hover_data=["Ingresos"],
                      color="Categoria del Producto")
fig3.update_layout(width=800, height=650)
st.plotly_chart(fig3, use_container_width=True)
    # Download the original dataset
csv = df.to_csv(index=False).encode('utf-8')
st.download_button('Download Data', data=csv, file_name="Data.csv", mime="text/csv")